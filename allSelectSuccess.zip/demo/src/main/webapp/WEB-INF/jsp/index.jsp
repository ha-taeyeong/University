<%@ page language="java" contentType="text/html; charset=UTF-8"
    pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>User List</title>
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
</head>
<body>

<h1>User List</h1>

<!-- 데이터가 출력될 곳 -->
<table id="userTable" border="1">
    <thead>
        <tr>
            <th>ID</th>
            <th>Email</th>
            <th>Name</th>
        </tr>
    </thead>
    <tbody>
        <!-- 여기서 데이터를 출력할 예정입니다. -->
    </tbody>
</table>

<script>
    // 페이지가 로드되면 API에서 데이터를 가져와서 테이블에 표시
    $(document).ready(function() {
        $.ajax({
            url: '/api/users',  // Spring Boot의 API 엔드포인트
            method: 'GET',
            success: function(data) {
                var tableBody = $("#userTable tbody");
                tableBody.empty(); // 테이블 초기화
                // API에서 반환된 데이터로 테이블 채우기
                data.forEach(function(user) {
                    tableBody.append(
                        "<tr>" +
                            "<td>" + user.id + "</td>" +
                            "<td>" + user.email + "</td>" +
                            "<td>" + user.name + "</td>" +
                        "</tr>"
                    );
                });
            },
            error: function() {
                alert("데이터를 불러오는 데 실패했습니다.");
            }
        });
    });
</script>

</body>
</html>
