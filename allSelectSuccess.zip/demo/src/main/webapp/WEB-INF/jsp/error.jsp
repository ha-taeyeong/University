<%@ page contentType="text/html;charset=UTF-8" language="java" %>
<html>
<head>
    <title>Error</title>
</head>
<body>
    <h1>Error: Something went wrong</h1>
    <p>The page you requested could not be found. Please try again later.</p>
</body>
</html>
