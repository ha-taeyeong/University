package com.example.demo.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.example.demo.dto.Users;

public interface UserRepository extends JpaRepository<Users, Integer> {
    // JpaRepository에서 제공하는 기본 findAll() 메서드를 사용하여 전체 사용자 조회
}
