package com.example.demo.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ResponseBody;

@Controller
public class HomeController {

    // 1. 루트 URL (/)로 들어오는 요청은 index.jsp 파일을 반환
    @GetMapping("/")
    public String index() {
        return "index";  // "index.jsp" 파일을 반환
    }

    // 2. /welcome URL로 들어오는 요청은 JSON 응답을 반환
    @GetMapping("/home/welcome")
    @ResponseBody
    public String welcomeMessage() {
        return "{\"message\": \"Welcome to My Spring Boot Application\"}";
    }
}
