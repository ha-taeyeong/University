package com.example.demo.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.example.demo.dto.Users;
import com.example.demo.repository.UserRepository;
import java.util.List;

@Service
public class UserService {

    @Autowired
    private UserRepository userRepository;

    // 전체 사용자 목록 조회
    public List<Users> getAllUsers() {
        return userRepository.findAll();  // findAll() 메서드를 사용하여 전체 데이터를 조회
    }
}
