package com.example.demo.service;

import org.springframework.stereotype.Service;

@Service
public class HomeService {

	// 1. 메시지 반환 (JSP용)
    public String getWelcomeMessage() {
        return "Welcome to My Spring Boot Application";
    }

    // 2. 홈 페이지 메시지 (JSON용)
    public String getHomeMessage() {
        return "This is the home page of the RESTful API";
    }
}
