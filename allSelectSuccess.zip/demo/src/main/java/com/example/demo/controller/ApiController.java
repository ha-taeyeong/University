package com.example.demo.controller;

import com.example.demo.service.HomeService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class ApiController {

    private final HomeService homeService;

    @Autowired
    public ApiController(HomeService homeService) {
        this.homeService = homeService;
    }

    // /welcome URL 요청에 대해 JSON 응답을 반환
    @GetMapping("/welcome")
    public String welcomeMessage() {
        return "{\"message\": \"" + homeService.getWelcomeMessage() + "\"}";
    }

    // /home URL 요청에 대해 JSON 응답을 반환
    @GetMapping("/home")
    public String homeMessage() {
        return "{\"message\": \"" + homeService.getHomeMessage() + "\"}";
    }
}
