public class Enc {
	
}
