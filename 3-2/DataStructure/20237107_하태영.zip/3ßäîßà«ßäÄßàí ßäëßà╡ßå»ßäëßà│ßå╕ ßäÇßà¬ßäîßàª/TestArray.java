
public class TestArray {
	public static void main(String[] args) {
		int a[] = { 6, 8, 1, 9, 2, 10 };
		for(int i=0; i<a.length; i++) {
			System.out.println(a[i]);
		}
	}
}
