<%@ page language="java" contentType="text/html; charset=UTF-8"
    pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Welcome to Spring Boot</title>
</head>
<body>
    <h1>Welcome to My Spring Boot Application</h1>
</body>
</html>
